import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.List;
import java.util.ArrayList;

public class CalculatorProject {
    private static double result;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // the scanner tool helps us recieve input from user.
        List<Double> numbers = new ArrayList<>();
        double result = 0;

        while (true) {
            // Display the calculator menu
            System.out.println("Calculator Menu: ");
            System.out.println("1. Basic Arithmetic ");
            System.out.println("2. Statistics Function ");
            System.out.println("3. Scientific Function ");
            System.out.println("4. Clear ");
            System.out.println("5. Exit ");
            System.out.print("Choose type of function being used (1-5): ");

            int choice;
            try {
                // This reads the user choice
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                // This prints an error when the numbers 1-5 are not chosen
                System.out.println("Error was detected, please enter a valid choice of function.");
                scanner.nextLine();
                continue;
            }

            if (choice == 5) {
                // Exits the calculator
                System.out.println("Exiting Calculator ");
                break;
            } else if (choice == 4) {
                // Clear the list of numbers
                System.out.println("Cleared");
                continue;
            }

            numbers.clear();

            if (choice == 1 || choice == 2) {
                if (choice == 1) {
                    // Basic Arithmetic operation
                    processBasicArithmetic(scanner, numbers);
                } else {
                    // Static Function operation
                    processStatistics(scanner, numbers);
                }
            } else if (choice == 3) {
                // Scientific Functions operation
                processScientificFunctions(scanner, numbers);
            } else {
                // Invalid choice which shows error
                System.out.println("Error, please choose valid function.(1-5)");
            }
        }
    }

    private static void processBasicArithmetic(Scanner scanner, List<Double> numbers) {
        // Display's the basic arithmetic menu
        System.out.println("Basic Arithmetic Menu: ");
        System.out.println("1. Addition ");
        System.out.println("2. Subtraction ");
        System.out.println("3. Multiplication ");
        System.out.println("4. Division ");
        System.out.print("Enter basic arithmetic (1-4): ");

        int basicChoice;
        try {
            // Basic Arithmetic choice
            basicChoice = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Error was detected, please enter a valid choice of Basic Arithmetic.(1-4)");
            scanner.nextLine();
            return;
        }

        if (basicChoice >= 1 && basicChoice <= 4) {
            // Reads two numbers said by the user
            System.out.print("Enter first number: ");
            numbers.add(scanner.nextDouble());

            System.out.print("Enter second number: ");
            numbers.add(scanner.nextDouble());

            switch (basicChoice) { // switch cases allow you to have different cases and go through
                // the different scenerios seemlessly.
                case 1:
                    // Addition occurs
                    result = numbers.get(0) + numbers.get(1);
                    break;
                case 2:
                    // Subtraction occurs
                    result = numbers.get(0) - numbers.get(1);
                    break;
                case 3:
                    // Multiplication occurs
                    result = numbers.get(0) * numbers.get(1);
                    break;
                case 4:
                    // Division occurs
                    if (numbers.get(1) == 0) {
                        System.out.println("Error: Dividing by zero is not allowed.");
                    } else {
                        result = numbers.get(0) / numbers.get(1);
                    }
                    break;
            }
            // Displays the result or answer
            System.out.println("Result: " + result);
        }
    }

    private static void processStatistics(Scanner scanner, List<Double> numbers) {
        // Display's the Static Function menu
        System.out.println("Statistics Function Menu: ");
        System.out.println("1. Mean ");
        System.out.println("2. Standard Deviation ");
        System.out.println("3. Variance ");
        System.out.println("4. Clear ");
        System.out.print("Enter statistical function (1-4): ");

        int statChoice;
        try {
            // Static Function choice
            statChoice = scanner.nextInt();
        } catch (InputMismatchException e) {
            // This prints an error when the numbers 1-4 are not chosen
            System.out.println("Error was detected, please enter a valid choice of Statistics Function.(1-4)");
            scanner.nextLine();
            return;
        }

        if (statChoice == 4) {
            System.out.println("Cleared");
            return;
        }

        System.out.print("Enter the number of data points: ");
        int numDataPoints = scanner.nextInt();

        System.out.println("Enter the data points: ");
        for (int i = 0; i < numDataPoints; i++) {
            numbers.add(scanner.nextDouble());
        }

        switch (statChoice) {
            // Enter a choice from 1-4 from the Static Function menu
            case 1:
                // Mean Function occurs
                result = calculateMean(numbers);
                break;
            case 2:
                // Standard Deviation function occurs
                result = calculateStandardDeviation(numbers);
                break;
            case 3:
                // Variance Function occurs
                result = calculateVariance(numbers);
                break;
            default:
                // Error occurs is a number 1-4 is not chosen
                System.out.println("Error please choose valid function. (1-4)");
        }

        System.out.println("Result: " + result);
    }

    private static void processScientificFunctions(Scanner scanner, List<Double> numbers) {
        // Display's the Scientific Function menu
        System.out.println("Scientific Function Menu: ");
        System.out.println("1. Square Root ");
        System.out.println("2. Exponential ");
        System.out.println("3. Sine (degrees) ");
        System.out.println("4. Cosine (degrees) ");
        System.out.println("5. Tangent (degrees) ");
        System.out.println("6. Logarithm ");
        System.out.println("7. Clear ");
        System.out.print("Enter scientific function (1-7): ");

        int scientificChoice;
        try {
            // Scientific Function choice
            scientificChoice = scanner.nextInt();
        } catch (InputMismatchException e) {
            // Handle input which displays error
            System.out.println("Error was detected, please enter a valid choice of Scientific Function.(1-7)");
            scanner.nextLine();
            return;
        }

        if (scientificChoice == 7) {
            System.out.println("Cleared");
            return;
        }

        if (scientificChoice == 1 || scientificChoice == 2 || (scientificChoice >= 3 && scientificChoice <= 6)) {
            System.out.print("Enter the number: ");
            numbers.add(scanner.nextDouble());

            switch (scientificChoice) {
                case 1:
                    // Square Root Function Occurs
                    result = Math.sqrt(numbers.get(0));
                    break;
                case 2:
                    // Exponent Function occurs
                    result = Math.exp(numbers.get(0));
                    break;
                case 3:
                    // Trigonometric functions occurs and is answered in radians
                    double num1 = numbers.get(0);
                    double rads = Math.toRadians(num1);
                    result = Math.sin(rads);
                    break;
                case 4:
                    double num2 = numbers.get(0);
                    double rads1 = Math.toRadians(num2);
                    result = Math.cos(rads1);
                    break;
                case 5:
                    double num3 = numbers.get(0);
                    double rads2 = Math.toRadians(num3);
                    result = Math.tan(rads2);
                    break;
                case 6:
                    // Logarithm function occurs
                    System.out.print("Enter the base for logarithm: ");
                    double base = scanner.nextDouble();
                    result = Math.log(numbers.get(0)) / Math.log(base);
                    break;
            }

            // Displays result
            System.out.println("Result: " + result);
        } else {
            System.out.println("Invalid choice. Please choose a number between 1 and 7.");
        }
    }

    // Calculate the mean (average) of a list of numbers.
    private static double calculateMean(List<Double> data) {
        double sum = 0;
        // // Sums up numbers
        for (double number : data) {
            sum += number;
        }
        // Return the mean by dividing the sum by the number of elements in the list.
        return sum / data.size();
    }

    private static double calculateVariance(List<Double> data) {
        double mean = calculateMean(data);
        double sumSquaredDifferences = 0;
        for (double number : data) {
            sumSquaredDifferences += Math.pow(number - mean, 2);
        }
        return sumSquaredDifferences / data.size();
    }

    private static double calculateStandardDeviation(List<Double> data) {
        return Math.sqrt(calculateVariance(data));
    }
}